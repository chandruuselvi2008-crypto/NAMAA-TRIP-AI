import json
import os
from collections import defaultdict

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "destinations.json")

with open(DATA_PATH, encoding="utf-8") as f:
    DESTINATIONS = json.load(f)

INTERESTS = [
    "Nature", "Culture & Heritage", "Adventure", "Beaches",
    "Food", "Wildlife", "Spiritual", "Family-friendly"
]
EXPERIENCE_TYPES = ["Balanced", "Relaxed", "Adventure-focused", "Culture-focused", "Nature-focused"]

EXPERIENCE_TAGS = {
    "Balanced": set(),
    "Relaxed": {"relaxed", "family"},
    "Adventure-focused": {"adventure", "nature"},
    "Culture-focused": {"culture", "spiritual", "food"},
    "Nature-focused": {"nature", "wildlife", "beach"},
}

def _tags_for_interest(interest):
    mapping = {
        "Nature": {"nature"},
        "Culture & Heritage": {"culture"},
        "Adventure": {"adventure"},
        "Beaches": {"beach"},
        "Food": {"food"},
        "Wildlife": {"wildlife"},
        "Spiritual": {"spiritual"},
        "Family-friendly": {"family"},
    }
    return mapping.get(interest, set())

def _score(place, requested, experience):
    tags = set(place["tags"])
    interest_tags = set()
    for item in requested:
        interest_tags |= _tags_for_interest(item)
    score = len(tags & interest_tags) * 4
    score += len(tags & EXPERIENCE_TAGS.get(experience, set())) * 1.5
    score += place.get("popularity", 1) * 0.1
    return score

def build_itinerary(days, budget, interests, experience, starting_city, travellers):
    """Create a transparent, offline itinerary using Karnataka destination data."""
    days = max(1, min(int(days), 14))
    budget = max(500, int(budget))
    travellers = max(1, int(travellers))
    requested = interests or ["Culture & Heritage", "Nature"]

    ranked = sorted(
        DESTINATIONS,
        key=lambda p: _score(p, requested, experience),
        reverse=True,
    )

    # Keep the itinerary varied by avoiding duplicate destinations.
    chosen = []
    used_regions = set()
    for place in ranked:
        if place["name"] in {p["name"] for p in chosen}:
            continue
        chosen.append(place)
        if len(chosen) >= min(days * 2, len(DESTINATIONS)):
            break

    # Budget-aware activity suggestions: estimates are per person for the full trip.
    estimated_per_person = sum(p["daily_cost"] for p in chosen[:days]) + max(0, days - 1) * 900
    budget_note = ""
    if estimated_per_person > budget / travellers:
        budget_note = (
            "This selection may exceed your budget. Consider fewer paid activities, "
            "public transport, homestays, or shortening the trip."
        )

    day_plans = []
    for i in range(days):
        place = chosen[i % len(chosen)]
        activities = place["activities"]
        day_plans.append({
            "day": i + 1,
            "destination": place["name"],
            "region": place["region"],
            "summary": place["summary"],
            "morning": activities[0],
            "afternoon": activities[1] if len(activities) > 1 else "Explore the local area at your own pace",
            "evening": activities[2] if len(activities) > 2 else "Enjoy local food and rest",
            "food": place["food"],
            "travel_tip": place["travel_tip"],
            "estimated_cost": place["daily_cost"],
            "tags": place["tags"],
            "map_query": place["map_query"],
        })

    total_estimate = estimated_per_person * travellers
    return {
        "days": days,
        "budget": budget,
        "travellers": travellers,
        "interests": requested,
        "experience": experience,
        "starting_city": starting_city,
        "day_plans": day_plans,
        "estimated_per_person": estimated_per_person,
        "total_estimate": total_estimate,
        "budget_note": budget_note,
        "budget_fit": total_estimate <= budget,
        "disclaimer": "Costs are illustrative estimates, not live prices. Check opening hours, transport, weather, and local advisories before travel.",
    }
