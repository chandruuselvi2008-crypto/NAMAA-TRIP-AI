from flask import Flask, render_template, request
from planner import build_itinerary, INTERESTS, EXPERIENCE_TYPES

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    itinerary = None
    error = None
    form = {
        "days": "3",
        "budget": "10000",
        "interests": ["Nature", "Culture & Heritage"],
        "experience": "Balanced",
        "starting_city": "Bengaluru",
        "travellers": "2",
    }
    if request.method == "POST":
        form = {
            "days": request.form.get("days", "3"),
            "budget": request.form.get("budget", "10000"),
            "interests": request.form.getlist("interests"),
            "experience": request.form.get("experience", "Balanced"),
            "starting_city": request.form.get("starting_city", "Bengaluru").strip() or "Bengaluru",
            "travellers": request.form.get("travellers", "2"),
        }
        try:
            days = max(1, min(14, int(form["days"])))
            budget = max(500, int(form["budget"]))
            travellers = max(1, min(20, int(form["travellers"])))
            itinerary = build_itinerary(
                days=days,
                budget=budget,
                interests=form["interests"],
                experience=form["experience"],
                starting_city=form["starting_city"],
                travellers=travellers,
            )
        except (ValueError, TypeError):
            error = "Please enter valid numbers for days, budget, and travellers."
    return render_template(
        "index.html",
        itinerary=itinerary,
        error=error,
        form=form,
        interests=INTERESTS,
        experience_types=EXPERIENCE_TYPES,
    )

@app.route("/health")
def health():
    return {"status": "ok", "project": "AI Travel Planner for Karnataka"}

if __name__ == "__main__":
    app.run(debug=True)
