# AI Travel Planner for Karnataka

A beginner-friendly Flask web app for the **Kannada Technology Challenge – Problem Statement 06: AI Travel Planner for Karnataka**.

It creates a personalized, day-by-day itinerary using the traveller's:
- interests (nature, culture, adventure, beaches, food, wildlife, spirituality, family travel)
- available trip duration
- total budget and number of travellers
- preferred experience style
- starting city

## Features

- Responsive web interface
- Karnataka-focused destination dataset
- Itinerary generation and interest matching
- Estimated trip costs and budget-fit warning
- Local food suggestions and practical travel tips
- No API key required; works offline after dependencies are installed
- Health endpoint at `/health`

> **Project note:** The itinerary engine is a transparent, local recommendation algorithm, not a connected large-language-model service. This makes the demo easy to run. You can later connect an LLM or live maps/pricing API if your hackathon requires generative AI or live data.

## Tech stack

- Python
- Flask
- HTML, CSS, Jinja templates
- JSON destination dataset

## Run locally

### 1. Install Python
Use Python 3.10 or newer.

### 2. Download or clone this repository
```bash
git clone https://github.com/YOUR-USERNAME/ai-travel-planner-karnataka.git
cd ai-travel-planner-karnataka
```

If you downloaded the ZIP, extract it and open the extracted folder in VS Code.

### 3. Create a virtual environment

Windows:
```bash
py -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies
```bash
pip install -r requirements.txt
```

### 5. Start the app
```bash
python app.py
```

Open `http://127.0.0.1:5000` in your browser.

## Project structure

```text
ai-travel-planner-karnataka/
├── app.py
├── planner.py
├── requirements.txt
├── README.md
├── .gitignore
├── data/
│   └── destinations.json
├── static/
│   └── style.css
└── templates/
    └── index.html
```

## Test the health endpoint

Open `http://127.0.0.1:5000/health`. Expected response:
```json
{"project": "AI Travel Planner for Karnataka", "status": "ok"}
```

## Upload to GitHub

1. Create a new repository on GitHub named `ai-travel-planner-karnataka`.
2. Extract this project ZIP.
3. Open a terminal inside the project folder.
4. Run:
```bash
git init
git add .
git commit -m "Build AI Travel Planner for Karnataka"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ai-travel-planner-karnataka.git
git push -u origin main
```
5. Replace `YOUR-USERNAME` with your GitHub username.

Alternatively, use GitHub Desktop: add the extracted folder as a local repository, commit the files, then publish the repository.

## Suggested repository description

`A Flask-based Karnataka travel planner that recommends personalized day-wise itineraries based on interests, duration, budget, and travel style.`

## Limitations and responsible use

- Destination costs are rough demonstration estimates, not quotes.
- Opening hours, transport, weather, access and availability can change; verify before travel.
- The app does not book hotels, tickets, transport, or safaris.
- Do not treat generated suggestions as live travel advisories.
- The included destination list is a starter dataset, not a complete tourism directory.

## Future enhancements

- Kannada and English interface
- LLM-powered itinerary explanations
- Interactive map and route-distance estimation
- Live weather and transport data
- Save/export itinerary as PDF
- Hotel and transport preference filters
- User accounts and saved trips

## Problem statement

**06 – AI Travel Planner for Karnataka:** Develop an AI-powered travel planner that creates personalized Karnataka itineraries based on a traveller's interests, available time, budget, and preferred type of experience.
